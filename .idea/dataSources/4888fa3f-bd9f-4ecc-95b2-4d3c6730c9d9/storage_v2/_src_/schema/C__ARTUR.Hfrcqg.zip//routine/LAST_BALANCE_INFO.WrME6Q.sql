create procedure last_balance_info as
lastBalanceId number;
begin
dbms_output.enable();
select b.id into lastBalanceId from BALANCE b order by b.create_date desc fetch first 1 rows only;
for i in (
select b.id, b.amount, o.id oid, (o.debit-o.credit) operation_amount from BALANCE b
    join operations o on o.balance_id=b.id where o.credit_date < b.create_date and b.id=lastBalanceId
    )
loop
dbms_output.put_line('ID=' || i.id || ', AMOUNT=' || i.amount || ', O.ID=' || i.oid || ', O.AMOUNT=' || i.operation_amount);
END LOOP;
end;
/

