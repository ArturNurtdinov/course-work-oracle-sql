create view FIRST_VIEW as
(SELECT a.id, a.CREATE_DATE, a.DEBIT, a.CREDIT, a.AMOUNT, SUM(o.DEBIT) prihod, SUM(o.CREDIT) rashod FROM BALANCE a
JOIN OPERATIONS o on o.balance_id=a.id WHERE o.CREDIT_DATE > a.CREATE_DATE group by a.id, a.debit, a.credit, a.amount, a.create_date)
/

