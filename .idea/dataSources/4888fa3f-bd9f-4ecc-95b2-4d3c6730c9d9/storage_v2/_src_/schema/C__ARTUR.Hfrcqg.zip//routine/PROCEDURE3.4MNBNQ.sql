create procedure procedure3(balanceId in number) as
articleId number;
articleName varchar(50);
creditAmount number;
begin
dbms_output.enable();
select a.id aid, sum(o.credit) credit_amount into articleId, creditAmount from OPERATIONS o
    join ARTICLES a on a.id=o.article_id where o.balance_id=balanceId group by a.id order by credit_amount desc fetch first 1 rows only;
select a.name into articleName from articles a where a.id = articleId;
dbms_output.put_line('NAME=' || articleName);
end;
/

