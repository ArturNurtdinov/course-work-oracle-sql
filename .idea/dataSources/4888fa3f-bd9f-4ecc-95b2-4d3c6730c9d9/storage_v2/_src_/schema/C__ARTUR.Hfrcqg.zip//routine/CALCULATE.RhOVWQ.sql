create procedure calculate(dateFrom in date, dateTo in date, artics in arrayType, operationType in varchar) as
CURSOR curs is select o.id from operations o where o.article_id member of artics and o.credit_date between dateFrom AND dateTo;
operation_id number;
totalSum number;
currentSum number;
articleId number;
oaid number;
percentage float;
results arrayType;
firstType number;
savedSum number;
begin
dbms_output.enable();
firstType := artics(1);
savedSum := 0;
results := arrayType(0, 0);
if (operationType = 'debit') then
    open curs;
    loop
    fetch curs into operation_id;
    EXIT WHEN curs%notfound;
    select o.debit, o.article_id into currentSum, oaid from operations o where o.id = operation_id;
    select sum(o.debit) into totalSum from operations o;
    percentage := round(currentSum / totalSum * 100);
    if (firstType = oaid) then
        savedSum := results(1);
        results(1) := savedSum + percentage;
    else 
        savedSum := results(2);
        results(2) := savedSum + percentage;
    end if;
    end loop;
    dbms_output.put_line('ARTICLE_ID= ' || artics(1) || ', PERCENT = ' || results(1));
    dbms_output.put_line('ARTICLE_ID= ' || artics(2) || ', PERCENT = ' || results(2));
end if;
if (operationType = 'credit') then
    open curs;
    loop
    fetch curs into operation_id;
    EXIT WHEN curs%notfound;
    select o.credit, o.article_id into currentSum, oaid from operations o where o.id = operation_id;
    select sum(o.credit) into totalSum from operations o;
    percentage := round(currentSum / totalSum * 100);
    if (firstType = oaid) then
        savedSum := results(1);
        results(1) := savedSum + percentage;
    else 
        savedSum := results(2);
        results(2) := savedSum + percentage;
    end if;
    end loop;
    dbms_output.put_line('ARTICLE_ID= ' || artics(1) || ', PERCENT = ' || results(1));
    dbms_output.put_line('ARTICLE_ID= ' || artics(2) || ', PERCENT = ' || results(2));
end if;
if (operationType = 'amount') then
    open curs;
    loop
    fetch curs into operation_id;
    EXIT WHEN curs%notfound;
    select (abs(o.credit - o.debit)), o.article_id into currentSum, oaid from operations o where o.id = operation_id;
    select sum(abs(o.credit - o.debit)) into totalSum from operations o;
    percentage := round(currentSum / totalSum * 100);
    if (firstType = oaid) then
        savedSum := results(1);
        results(1) := savedSum + percentage;
    else 
        savedSum := results(2);
        results(2) := savedSum + percentage;
    end if;
    end loop;
    dbms_output.put_line('ARTICLE_ID= ' || artics(1) || ', PERCENT = ' || results(1));
    dbms_output.put_line('ARTICLE_ID= ' || artics(2) || ', PERCENT = ' || results(2));
end if;
end;
/

