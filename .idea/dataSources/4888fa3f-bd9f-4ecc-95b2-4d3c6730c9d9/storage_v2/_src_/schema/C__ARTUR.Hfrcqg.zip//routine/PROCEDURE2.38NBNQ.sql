create procedure procedure2(article1 in number, article2 in number) as
sum1 number;
id1 number;
row1 number;
sum2 number;
id2 number;
row2 number;
begin
dbms_output.enable();
for i in (select bm.id from BALANCE bm) loop
select COUNT(*) into row1 from balance b1 join operations o1 on o1.balance_id=b1.id where o1.article_id=article1 and b1.id=i.id;
select COUNT(*) into row2 from balance b2 join operations o2 on o2.balance_id=b2.id where o2.article_id=article2 and b2.id=i.id;
if (row1 > 0 and row2 > 0) then 
select b.id, sum(o.debit) into id1, sum1 from BALANCE b
    join OPERATIONS o on o.balance_id=b.id and o.article_id=article1 where b.id = i.id group by b.id;

select b.id, sum(o.debit) into id2, sum2 from BALANCE b
    join OPERATIONS o on o.balance_id=b.id and o.article_id=article2 where b.id = i.id group by b.id;

if (sum1 > sum2) then
dbms_output.put_line('ID=' || i.id);
end if;
end if;
end loop;
end;
/

