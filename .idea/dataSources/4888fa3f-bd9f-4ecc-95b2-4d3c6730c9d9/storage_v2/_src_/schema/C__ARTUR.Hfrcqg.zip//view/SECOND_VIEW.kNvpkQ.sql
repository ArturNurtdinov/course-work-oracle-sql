create view SECOND_VIEW as
(SELECT a.id, a.CREATE_DATE, a.DEBIT, a.CREDIT, a.AMOUNT, count(o.id) operations FROM BALANCE a
join operations o on o.balance_id=a.id WHERE o.CREDIT_DATE <= a.CREATE_DATE group by a.id, a.debit, a.credit, a.amount, a.create_date)
/

