create trigger OPERATION_DELETE_CHECK
    before delete
    on OPERATIONS
    for each row
declare
    rowsNumber number;
    begin
    select COUNT(*) into rowsNumber from balance b where b.id=:new.balance_id and :new.credit_date<b.create_date;
    if (rowsNumber > 0) then
        rollback;
        end if;
    end;
/

